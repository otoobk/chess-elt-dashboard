from pathlib import Path
import pandas as pd
import numpy as np
from utils.api_utils import fetch_all_games
from utils.chess_utils import create_games_dataframe, create_games_summary_dataframe, create_openings_tree, calculate_eco_opening
from utils.file_utils import ensure_dir, load_csv, save_csv, save_csv_with_index
from utils.config_utils import config, PROJ_PATH

def main():
    username = config["username"]
    raw_dir = (Path(PROJ_PATH) / config["raw_dir"]).resolve()
    clean_dir = (Path(PROJ_PATH) / config["clean_dir"]).resolve()
    ref_dir = (Path(PROJ_PATH) / config["ref_dir"]).resolve()
    openings_file = config["openings_file"]
    all_archives = True if config["all_archives"] == "True" else False
    headers = config["headers"]

    ensure_dir(raw_dir)
    ensure_dir(clean_dir)

    games = fetch_all_games(username, raw_dir, headers, all_archives)
    openings_df = load_csv((ref_dir / openings_file).resolve())
    
    openings_df["moves_list"] = openings_df["pgn"].str.replace(r"\d+\.", "", regex=True).str.strip().str.split()
    openings_tree = create_openings_tree(openings_df)
    
    games_df = create_games_dataframe(username, games, openings_tree)
    games_df = calculate_eco_opening(games_df, openings_tree)
    games_df.index.name = "game_rank"
    summary_df = create_games_summary_dataframe(games_df)

    last_n = 20
    kpi_results = []
    top_openings_results = []

    for time_class, group in games_df.groupby("time_class"):
        group = group.sort_values("date")

        if group.empty:
            continue    

        current_elo = group.iloc[-1]["user_rating"]

        if len(group) >= last_n:
            prev_elo = group.iloc[-last_n]["user_rating"]
            elo_change = current_elo - prev_elo
            last_n_games = group.iloc[-last_n:]
        else:
            prev_elo = group.iloc[0]["user_rating"]
            elo_change = current_elo - prev_elo
            last_n_games = group

        win_count = (group["win_loss"] == "win").sum()
        loss_count = (group["win_loss"] == "loss").sum()
        draw_count = (group["win_loss"] == "draw").sum()
        total_games = len(group)

        win_pct = (win_count / total_games) * 100 if total_games else None

        win_count_last_n = (last_n_games["win_loss"] == "win").sum()
        loss_count_last_n = (last_n_games["win_loss"] == "loss").sum()
        draw_count_last_n = (last_n_games["win_loss"] == "draw").sum()
        total_games_last_n = len(last_n_games)

        win_pct_last_n = (win_count_last_n / total_games_last_n) * 100 if total_games_last_n else None

        filtered = group[group["win_loss"].isin(["win", "loss"])]

        top_openings = (
            filtered.groupby(["opening", "win_loss"])
            .size()
            .reset_index(name="count")
            .pivot_table(index="opening", columns="win_loss", values="count", fill_value=0)
            .reset_index()
        )

        top_openings.columns.name = None
        top_openings = top_openings.rename(columns={"win": "win_count", "loss": "loss_count"})

        for col in ["win_count", "loss_count"]:
            if col not in top_openings.columns:
                top_openings[col] = 0

        top_openings["total_games"] = top_openings["win_count"] + top_openings["loss_count"]
        top_openings = top_openings.sort_values("total_games", ascending=False).head(5)

        # Add time_class column to top openings for exporting
        top_openings["time_class"] = time_class
        top_openings_results.append(top_openings)

        kpi_results.append({
            "time_class": time_class,
            "current_rating": current_elo,
            "rating_change_last_n": elo_change,
            "win_count": win_count,
            "loss_count": loss_count,
            "draw_count": draw_count,
            "win_pct": np.round(win_pct, 2),
            "win_count_10": win_count_last_n,
            "loss_count_10": loss_count_last_n,
            "draw_count_10": draw_count_last_n,
            "win_pct_10": np.round(win_pct_last_n, 2)
        })

    kpi_df = pd.DataFrame(kpi_results)
    top_openings_df = pd.concat(top_openings_results, ignore_index=True)

    save_csv_with_index(games_df, clean_dir / f"{username}_games.csv")
    save_csv(summary_df, clean_dir / f"{username}_summary.csv")
    save_csv(kpi_df, clean_dir / f"{username}_kpis.csv")
    save_csv(top_openings_df, clean_dir / f"{username}_top_openings.csv")

if __name__ == "__main__":
    main()
